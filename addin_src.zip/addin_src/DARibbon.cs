using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;
using Autodesk.Revit.Attributes;

namespace DynamoAutomation
{
    /// <summary>
    /// Implements the Revit add-in interface IExternalApplication.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    [Journaling(JournalingMode.UsingCommandData)]
    public class Swallower : IExternalApplication
    {
        /// <summary>
        /// Implements the external application which should be called when 
        /// Revit starts before a file or default template is actually loaded.
        /// </summary>
        /// <param name="application">The controlled application.</param>
        /// <returns>Return the status of the external application.</returns>
        public Result OnStartup(UIControlledApplication application)
        {
            try
            {
                // DIMITAR: Here's where I got stuck - I didn't know how to access CommandData in the UIApp context
                // So I made an IExternalApplication (see below) instead which I think is probably very silly
                Result jCheck = new ExtCmdCheckJournalData();
                // What would need to happen here:
                // 1. Call the function that checks whether the required journal key is here
                // 2a. For debugging puposes show a TaskDialog
                // 2b. Once that works uncomment the lines below to subscribe to the events

                // Subscribe to the DialogBoxShowing event to be notified when Revit is about to show a dialog box or a message box.
                // application.DialogBoxShowing += new EventHandler<DialogBoxShowingEventArgs>(DismissDialogs);
                // Subscribe to the FailuresProcessing event to be notified when Revit is about to show a warning.
                // application.FailuresProcessing += new EventHandler<FailuresProcessingEventArgs>(DismissWarnings);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("DynamoAutomation", ex.ToString());
                return Result.Failed;
            }

        }

        /// <summary>
        /// Implements the external application which should be called when Revit is about to exit.
        /// </summary>
        /// <param name="application">The controlled application.</param>
        /// <returns>Return the status of the external application.</returns>
        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

        /// <summary>
        /// Will dismiss all undesired dialogs
        /// </summary>
        private void DismissDialogs(object o, DialogBoxShowingEventArgs e)
        {
            TaskDialogShowingEventArgs t = e as TaskDialogShowingEventArgs;
            if (t != null)
            {
                // Call OverrideResult to cause the dialog to be dismissed with the specified return value ("No")
                // (int) is used to convert the enum TaskDialogResult.No to its integer value which is the data type required by OverrideResult
                e.OverrideResult((int)TaskDialogResult.No);
                // DIMITAR: Don't think saying NO to every dialog is a good solution here but I left this in as a placeholder
            }
        }

        /// <summary>
        /// Will dismiss all warnings
        /// </summary>
        private void DismissWarnings(object o, FailuresProcessingEventArgs e)
        {
            FailuresAccessor fa = e.GetFailuresAccessor();
            IList<FailureMessageAccessor> failList = new List<FailureMessageAccessor>();
            failList = fa.GetFailureMessages();
            // Inside event handler, get all warnings
            foreach (FailureMessageAccessor failure in failList)
            {
                fa.DeleteWarning(failure);
            }
        }
    }
    /// <summary>
    /// Check journal data
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class ExtCmdCheckJournalData : IExternalCommand
    {
        public Result Execute(ExternalCommandData cmdData, ref string msg, ElementSet elemSet)
        {
            // DIMITAR: This needs to be refined to actually access the key we want
            if (cmdData.JournalData == null)
            {
                return Result.Failed;
            }
            else
            {
                return Result.Succeeded;
            }
        }
    }
}